export class AgentCenter {
    constructor(
        public address : string,
        public alias : string
    ) {}
}
