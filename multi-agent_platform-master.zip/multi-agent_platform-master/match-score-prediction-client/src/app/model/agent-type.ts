export class AgentType {
    constructor(
        public name : string,
        public module : string,
        public host : string
    ) {}
}
